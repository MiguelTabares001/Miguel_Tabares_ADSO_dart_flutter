import 'package:actividad_parqueadero_2742550/vehicle.dart';
import 'package:flutter/material.dart';

class VehicleScreen extends StatefulWidget {
  const VehicleScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _VehicleScreenState createState() => _VehicleScreenState();
}

class _VehicleScreenState extends State<VehicleScreen> {
  final List<Vehicle> vehicles = [];
  final TextEditingController plateController = TextEditingController();
  final TextEditingController idController = TextEditingController();
  int? selectedLocation;

  void _addVehicle() {
    final newPlate = plateController.text;
    final newId = idController.text;
    final newLocation = selectedLocation;

    // Validaciones

    if (newPlate.isEmpty || newId.isEmpty || newLocation == null) {
      return; // No agregar si falta información
    }

    if (vehicles.any((vehicle) => vehicle.plate == newPlate)) {
      _showErrorSnackBar('La placa ya está registrada.');
      return;
    }

    if (vehicles.any((vehicle) => vehicle.id == newId)) {
      _showErrorSnackBar('La cédula ya está registrada.');
      return;
    }

    if (vehicles.any((vehicle) => vehicle.location == newLocation)) {
      _showErrorSnackBar('La ubicación ya está en uso.');
      return;
    }

    // Agregar el vehículo
    setState(() {
      vehicles.add(Vehicle(
        plate: newPlate,
        id: newId,
        location: newLocation,
      ));
      plateController.clear();
      idController.clear();
      selectedLocation = null;
    });
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _resetRecords() {
    setState(() {
      vehicles.clear();
    });
  }

  void _removeVehicle(int index) {
    setState(() {
      vehicles.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vehicle App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: plateController,
              decoration: const InputDecoration(labelText: 'Placa'),
            ),
            TextField(
              controller: idController,
              decoration: const InputDecoration(labelText: 'Cédula'),
            ),
            DropdownButton<int>(
              hint: const Text('Selecciona una ubicación'),
              value: selectedLocation,
              items: List.generate(20, (index) => index + 1).map((location) {
                return DropdownMenuItem<int>(
                  value: location,
                  child: Text('Ubicación $location'),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedLocation = value;
                });
              },
            ),
            ElevatedButton(
              onPressed: _addVehicle,
              child: const Text('Agregar Vehículo'),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: vehicles.length,
                itemBuilder: (context, index) {
                  final vehicle = vehicles[index];
                  return ListTile(
                    title: Text('Placa: ${vehicle.plate}'),
                    subtitle: Text('Cédula: ${vehicle.id}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => _removeVehicle(index),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: _resetRecords,
              child: const Text('Reiniciar Registros'),
            ),
          ],
        ),
      ),
    );
  }
}
