class Vehicle {
  String plate;
  String id;
  int location;

  Vehicle({required this.plate, required this.id, required this.location});
}
